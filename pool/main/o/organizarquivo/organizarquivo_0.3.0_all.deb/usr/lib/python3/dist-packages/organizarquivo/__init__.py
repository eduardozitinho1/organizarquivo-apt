"""Organizarquivo: organiza arquivos em pastas por tipo."""

__version__ = "0.3.0"
